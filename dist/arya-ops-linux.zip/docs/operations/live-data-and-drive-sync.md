# عملیات داده زنده و همگام‌سازی منابع

## ۱) فراهم‌کردن دسترسی Google Drive

دو روش پیشنهادی وجود دارد:

### روش تعاملی برای همین نشست

1. مرورگر Manus را روی یکی از لینک‌های Drive باز کنید.
2. با حسابی که دسترسی Viewer یا Editor به پوشه دارد وارد شوید.
3. پس از ورود، فایل‌ها و پوشه‌ها قابل بررسی و خلاصه‌سازی هستند.
4. این روش برای بررسی دستی مناسب است و **همگام‌سازی unattended** ایجاد نمی‌کند.

### روش عملیاتی برای همگام‌سازی فاز اول

برای همگام‌سازی خودکار، بهترین روش یک حساب سرویس یا OAuth محدودشده است:

1. در Google Cloud یک پروژهٔ جدا برای ARYA ایجاد کنید و Google Drive API را فقط
   برای همان پروژه فعال کنید.
2. یک Service Account بسازید و فقط ایمیل همان حساب را روی دو پوشهٔ Drive با
   سطح `Viewer` share کنید؛ سطح Editor لازم نیست.
3. کلید JSON را هرگز داخل Git، فایل `.env` commit‌شده یا پیام گفتگو قرار ندهید.
   آن را در Secret Manager/secret محیط عملیاتی بگذارید.
4. sync worker فقط metadata، hash فایل، زمان تغییر و نسخهٔ فایل را ثبت کند؛
   فایل اصلی را بدون نیاز کپی نکند و برای فایل‌های خارج از حوزه ردپا ثبت کند.
5. قبل از واردکردن سند به knowledge base، allowlist پسوند، اندازه، MIME type و
   پوشهٔ مجاز اعمال شود. لینک‌ها و منابع مالیاتی از دامنهٔ پروژه حذف شوند.
6. برای هر اجرای sync، manifest با `file_id`, `modified_time`, `sha256`, `status`
   ذخیره شود تا تکرارپذیری و rollback ممکن باشد.

برای حساب شخصی، OAuth کاربرمحور با refresh token محدود به Drive read-only از
Service Account مناسب‌تر است. توکن و client secret باید فقط در secret store
محیط عملیاتی نگه‌داری شوند.

### Worker پایتونی

برای اجرای قابل‌ردیابی sync و پردازش فایل‌ها از `scripts/drive_sync_worker.py`
استفاده کنید. حالت پیش‌فرض dry-run است:

```bash
PYTHONPATH=src python scripts/drive_sync_worker.py \
  --remote drive:arya-phase-one \
  --local-dir data/phase-one
```

پس از بررسی log، اجرای واقعی را با `--apply` انجام دهید:

```bash
PYTHONPATH=src python scripts/drive_sync_worker.py \
  --remote drive:arya-phase-one \
  --local-dir data/phase-one \
  --apply
```

Worker فایل‌های مجاز را با SHA-256 در `manifest.json` ثبت می‌کند، JSON/CSV را
به‌صورت سبک بررسی می‌کند و PDF/XLSX را برای استخراج امن بعدی در صف metadata
قرار می‌دهد. فایل‌های خارج از allowlist یا بزرگ‌تر از سقف، rejected می‌شوند.

## ۲) تست‌های اتصال زنده به بورس ایران

تست‌های واحد پروژه عمداً Mock هستند و نباید به بازار زنده وابسته شوند. تست زنده
باید به‌صورت **smoke test جداگانه** در محیط عملیاتی اجرا شود:

```bash
PYTHONPATH=src python scripts/live_tsetmc_smoke.py \
  --ticker فولاد --limit 10 --json
```

برای بررسی مستقیم snapshot لحظه‌ای market-watch نیز اجرا کنید:

```bash
PYTHONPATH=src python scripts/tsetmc_live_check.py \
  --ticker فولاد --json
```

این فرمان تعداد quoteهای دریافتی، quote معتبر، قیمت آخر، قیمت پایانی، حجم و
زمان بررسی را گزارش می‌کند. خروجی فقط health-check است و به هیچ مسیر سفارش‌گذاری
متصل نیست.

این تست موارد زیر را کنترل می‌کند:

- resolve شدن نماد در TSETMC
- دریافت حداقل تعداد کندل
- مثبت و معتبر بودن قیمت‌ها
- مرتب‌بودن timestampها
- ثبت زمان اجرای تست و آخرین timestamp داده

### سیاست اجرا

- smoke test در CI عمومی اجرا نشود؛ به شبکه و گاهی IP مناسب ایران نیاز دارد.
- در محیط عملیاتی با cron، scheduler یا health-check هر ۵ تا ۱۵ دقیقه اجرا شود؛
  در ساعات بسته‌بودن بازار، نتیجه با وضعیت `market_closed` تفسیر شود نه شکست داده.
- retry و timeout محدود باشد و بین درخواست‌ها backoff اعمال شود؛ از حلقهٔ بی‌نهایت
  و موازی‌سازی تهاجمی روی endpointهای TSETMC خودداری شود.
- شکست تست باید alert بدهد، اما نباید به‌تنهایی سفارش یا معامله ایجاد کند.
- دادهٔ آخرین موفق و زمان تازگی در storage نگه‌داری شود تا dashboard بتواند
  `stale_data` را از دادهٔ تازه جدا کند.
- مرحلهٔ بعدی باید market-watch و client-type را هم با contract test و fixture
  مصنوعی پوشش دهد.

## ۳) منابعی که به قابلیت تبدیل شدند

- منابع فیلتر TSETMC: حجم، ارزش معاملات، درصد تغییر، صف و قدرت خریدار →
  `arya.scanner.filters`
- بورس‌تریدر و نقشه بازار: پایش لحظه‌ای، جریان پول، watchlist و alert → درایور
  و scheduler فاز بعد
- CodalChart: رویداد افزایش سرمایه و اطلاعیه‌های بنیادی → adapter Codal فاز بعد
- Rahavard365 و ابزارهای نموداری: فیلتر، چندبازه‌ای و مقایسهٔ بازدهی → استراتژی
  روند-مومنتوم و برنامهٔ backtest
- منابع کریپتو و DEX: تحلیل wallet و نقدشوندگی → خارج از فاز اول بورس، ولی در
  قرارداد provider چندبازاره باقی می‌ماند.

منابع تبلیغاتی، حساب‌های کاربری و لینک‌های مالیاتی بوکمارک وارد منطق پروژه
نشده‌اند.
